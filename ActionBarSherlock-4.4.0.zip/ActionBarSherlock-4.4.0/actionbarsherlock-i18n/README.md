ActionBarSherlock i18n
======================

A library project which has translations of all of the strings used by ActionBarSherlock in the
most popular languages.

To update run `mvn org.holoeverywhere:resbuilder:build`.
