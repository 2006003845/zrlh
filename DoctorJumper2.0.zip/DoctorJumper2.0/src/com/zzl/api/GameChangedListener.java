package com.zzl.api;

public interface GameChangedListener {
	

}
