package com.zzl.api;

import android.media.MediaPlayer;

public class GameMedia extends MediaPlayer {

}
