package com.zzl.constant;

public class Constant {
	/**
	 * Game State
	 */
	public static final int STATE_01 = 1;

}
